package com.example.my_protfolio1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
