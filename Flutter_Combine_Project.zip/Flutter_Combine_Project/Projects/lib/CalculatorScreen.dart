import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';
import 'package:charts_flutter/flutter.dart' as charts;

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CalculatorScreen(),
    ),
  );
}

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _input = '';
  List<String> _history = [];
  List<charts.Series<PlotData, num>> _seriesList = [];

  void _handleButtonPressed(String buttonText) {
    setState(() {
      if (buttonText == '=') {
        _input = _calculateResult();
        _history.add(_input);
      } else if (buttonText == 'C') {
        _input = '';
      } else if (buttonText == 'Graph') {
        _plotGraph();
      } else {
        _input += (buttonText == 'x') ? '*' : buttonText;
      }
    });
  }

  String _calculateResult() {
    try {
      Parser p = Parser();
      Expression exp = p.parse(_input);
      ContextModel cm = ContextModel();
      double result = exp.evaluate(EvaluationType.REAL, cm);
      return result.toStringAsFixed(6); // Adjust precision as needed
    } catch (e) {
      return 'Error';
    }
  }

  void _plotGraph() {
    List<PlotData> data = [];
    Parser p = Parser();
    Expression exp = p.parse(_input.replaceAll('x', '*'));
    ContextModel cm = ContextModel();
    for (int i = -10; i <= 10; i++) {
      cm.bindVariableName('x', Number(i.toDouble()));
      double y = exp.evaluate(EvaluationType.REAL, cm);
      data.add(PlotData(i, y));
    }

    _seriesList = [
      charts.Series<PlotData, int>(
        id: 'Graph',
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
        domainFn: (PlotData plot, _) => plot.x,
        measureFn: (PlotData plot, _) => plot.y,
        data: data,
      )
    ];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Container(
          height: 300,
          child: charts.LineChart(_seriesList, animate: true),
        ),
      ),
    );
  }

  void _showHistory() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("History"),
        content: Container(
          width: double.maxFinite,
          height: 300,
          child: ListView.builder(
            itemCount: _history.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Text(_history[index]),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  void _showUnitConversion() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Unit Conversion"),
        content: Container(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildConversionButton("Length", _lengthConversion),
              _buildConversionButton("Weight", _weightConversion),
              _buildConversionButton("Temperature", _temperatureConversion),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  Widget _buildConversionButton(String title, Function conversionFunction) {
    return ElevatedButton(
      onPressed: () {
        Navigator.of(context).pop();
        conversionFunction();
      },
      child: Text(title),
    );
  }

  void _lengthConversion() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Length Conversion"),
        content: Container(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Convert between different length units."),
              // Add your length conversion logic here
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  void _weightConversion() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Weight Conversion"),
        content: Container(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Convert between different weight units."),
              // Add your weight conversion logic here
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  void _temperatureConversion() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Temperature Conversion"),
        content: Container(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Convert between different temperature units."),
              // Add your temperature conversion logic here
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1E1E1E),
      appBar: AppBar(
        title: Text("Calculator"),
        backgroundColor: Color(0xFF2E3139),
        actions: [
          IconButton(
            icon: Icon(Icons.history),
            onPressed: () => _showHistory(),
          ),
          IconButton(
            icon: Icon(Icons.swap_horiz),
            onPressed: () => _showUnitConversion(),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.all(32),
              alignment: Alignment.bottomRight,
              child: Text(
                _input,
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: const Color.fromARGB(255, 248, 246, 246),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Color(0xFF2E3139),
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: Column(
                children: [
                  _buildButtonRow(
                      ['C', 'sin', 'cos', 'tan'], Color(0xFF4CAF50)),
                  _buildButtonRow(
                      ['7', '8', '9', '/'], Color.fromARGB(255, 5, 50, 87)),
                  _buildButtonRow(
                      ['4', '5', '6', 'x'], Color.fromARGB(255, 5, 50, 87)),
                  _buildButtonRow(
                      ['1', '2', '3', '-'], Color.fromARGB(255, 5, 50, 87)),
                  _buildButtonRow(
                      ['0', '.', '=', '+'], Color.fromARGB(255, 5, 50, 87)),
                  _buildButtonRow(
                      ['sqrt', 'log', 'exp', 'pow'], Color(0xFF4CAF50)),
                  _buildButtonRow(['(', ')', '^', 'Graph'], Color(0xFF4CAF50)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButtonRow(List<String> buttonLabels, Color color) {
    return Expanded(
      child: Row(
        children: buttonLabels
            .map((label) => Expanded(child: _buildButton(label, color)))
            .toList(),
      ),
    );
  }

  Widget _buildButton(String buttonText, Color color) {
    return Container(
      margin: EdgeInsets.all(8),
      child: ElevatedButton(
        onPressed: () => _handleButtonPressed(buttonText),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Text(
          buttonText,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class PlotData {
  final int x;
  final double y;

  PlotData(this.x, this.y);
}
