import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: About(),
    debugShowCheckedModeBanner: false,
  ));
}

//stless
class About extends StatelessWidget {
  const About({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("lib/Assets/images/BG.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: const Padding(
          padding: EdgeInsets.only(top: 30.0, left: 30),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: AssetImage("lib/Assets/images/2-min.JPG"),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "MD. ALAMIN",
                        style: TextStyle(
                            fontSize: 25,
                            color: Color.fromARGB(255, 72, 2, 2),
                            fontFamily: "Bold"),
                      ),
                      Text(
                        "Programmer and Iot expert",
                        style: TextStyle(
                            fontSize: 14,
                            color: Color.fromARGB(179, 33, 132, 3),
                            fontFamily: "Robotor"),
                      )
                    ],
                  )
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Padding(
                padding: EdgeInsets.only(left: 30),
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.school,
                          size: 30,
                          color: Color.fromARGB(255, 2, 64, 75),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "B.sc in Computer Science & Engineering",
                          style: TextStyle(
                              fontSize: 18,
                              color: Color.fromARGB(234, 14, 0, 0),
                              fontFamily: "Robotor"),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.location_pin,
                          size: 30,
                          color: Color.fromARGB(255, 2, 64, 75),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "Uttara, Dhaka, Bangladesh, 1230",
                          style: TextStyle(
                              fontSize: 18,
                              color: Color.fromARGB(179, 20, 19, 19),
                              fontFamily: "Robotor"),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.email,
                          size: 30,
                          color: Color.fromARGB(255, 2, 64, 75),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "amin15-4230@diu.edu.bd",
                          style: TextStyle(
                              fontSize: 18,
                              color: Color.fromARGB(179, 17, 17, 17),
                              fontFamily: "Robotor"),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.phone,
                          size: 30,
                          color: Color.fromARGB(255, 2, 64, 75),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "+88001601885551",
                          style: TextStyle(
                              fontSize: 18,
                              color: Color.fromARGB(179, 19, 18, 18),
                              fontFamily: "Robotor"),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: Text(
                  "Assalamu alaikum, I am Md. Al Amin . I live in Dhaka. Currently I am a student of Daffodil International University. I am very simple person with creativity. I always takes my life within rules and disciplines. I have completed my SSC from B.H.B.F.C Shahin School and   HSC from Nawab Habibullah Model School & College.",
                  style: TextStyle(
                      fontSize: 15,
                      color: Color.fromARGB(255, 17, 17, 18),
                      fontFamily: "Robotor"),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "By Alamin",
                style: TextStyle(
                    fontSize: 15,
                    color: Color.fromARGB(255, 171, 206, 212),
                    fontFamily: "Robotor"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
