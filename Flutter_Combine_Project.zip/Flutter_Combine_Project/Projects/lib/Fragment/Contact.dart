import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Contact extends StatelessWidget {
  const Contact({Key? key}) : super(key: key);

  void _launchURL(String url) async {
    if (!await launch(url)) throw 'Could not launch $url';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contact'),
        backgroundColor: Color.fromARGB(255, 4, 117, 123),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("lib/Assets/images/BG.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildContactTile(
                title: "Phone",
                icon: Icons.phone,
                subtitle: "01601885551",
                url: "tel:01601885551",
              ),
              _buildContactTile(
                title: "Email",
                icon: Icons.mail,
                subtitle: "amin15-4230@diu.edu.bd",
                url: "mailto:amin15-4230@diu.edu.bd",
              ),
              _buildContactTile(
                title: "Facebook",
                icon: Icons.facebook,
                subtitle: "Alamin Hawlader",
                url: "https://www.facebook.com/AlaminHawlader",
              ),
              _buildContactTile(
                title: "linkedin",
                icon: Icons.facebook,
                subtitle: "Alamin Hawlader",
                url: "https://bd.linkedin.com/",
              ),
              _buildSocialMediaLinks(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContactTile({
    required String title,
    required IconData icon,
    required String subtitle,
    required String url,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.symmetric(vertical: 8),
      leading: Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 4, 117, 123),
          shape: BoxShape.circle,
        ),
        child: Icon(
          icon,
          color: Colors.white,
        ),
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(
          fontSize: 18,
          color: Colors.white70,
        ),
      ),
      onTap: () => _launchURL(url),
    );
  }

  Widget _buildSocialMediaLinks() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Follow Me',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        SizedBox(height: 10),
        Row(
          children: [
            _buildSocialMediaButton(
              icon: Icons.facebook,
              url: "https://www.facebook.com/AlaminHawlader",
              color: Colors.blue,
            ),
            SizedBox(width: 10),
            _buildSocialMediaButton(
              icon: Icons.link,
              url: "https://www.linkedin.com/in/MDALAMIN",
              color: Colors.blueAccent,
            ),
            _buildSocialMediaButton(
              icon: Icons.mail,
              url: "https://www.google.com/intl/en-US/gmail/about/",
              color: Colors.blueAccent,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSocialMediaButton({
    required IconData icon,
    required String url,
    required Color color,
  }) {
    return IconButton(
      icon: Icon(icon, color: Colors.white),
      color: color,
      onPressed: () => _launchURL(url),
      iconSize: 40,
      padding: EdgeInsets.all(0),
      constraints: BoxConstraints(),
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
    );
  }
}
