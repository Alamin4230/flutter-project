import 'package:flutter/material.dart';

class Experiences extends StatelessWidget {
  const Experiences({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("lib/Assets/images/BG.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Image.asset(
              "lib/Assets/images/cv.jpg", // Replace with your CV image path
              fit: BoxFit.contain, // Adjust the fit as needed
            ),
          ),
        ),
      ),
    );
  }
}
