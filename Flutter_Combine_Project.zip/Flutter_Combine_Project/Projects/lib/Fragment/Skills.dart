import 'package:flutter/material.dart';

class Skills extends StatelessWidget {
  const Skills({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Skills'),
        backgroundColor: Color.fromARGB(255, 29, 192, 214),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("lib/Assets/images/BG.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: ListView(
            children: [
              _buildSkillCard(
                Icons.code,
                "Programming Languages",
                "C, C++, Python, Java, Dart, Assembly, Shell Scripting",
              ),
              _buildSkillCard(Icons.computer, "IDE", "VS Code"),
              _buildSkillCard(Icons.code, "Version Control", "Git"),
              _buildSkillCard(Icons.design_services, "UI Design", "Flutter"),
              _buildSkillCard(Icons.layers, "Architecture", "Components"),
              _buildSkillCard(Icons.star, "Others", "Photography, Leadership"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSkillCard(IconData icon, String title, String subtitle) {
    return Card(
      color: Colors.white.withOpacity(0.8),
      margin: EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        leading: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 2, 64, 75),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: Colors.white,
          ),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 2, 64, 75),
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            fontSize: 16,
            color: Color.fromARGB(239, 14, 13, 13),
          ),
        ),
      ),
    );
  }
}
