import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;

class UploadCV extends StatefulWidget {
  const UploadCV({Key? key}) : super(key: key);

  @override
  _UploadCVState createState() => _UploadCVState();
}

class _UploadCVState extends State<UploadCV> {
  Uint8List? _fileBytes;
  String? _fileName;
  bool _uploading = false;
  String _uploadStatus = '';

  Future<void> pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx'],
    );

    if (result != null) {
      setState(() {
        _fileBytes = result.files.single.bytes;
        _fileName = result.files.single.name;
        _uploadStatus = 'File selected: $_fileName';
      });
    } else {
      setState(() {
        _uploadStatus = 'No file selected.';
      });
    }
  }

  Future<void> uploadFile() async {
    if (_fileBytes == null || _fileName == null) return;

    setState(() {
      _uploading = true;
      _uploadStatus = 'Uploading...';
    });

    Reference storageReference =
        FirebaseStorage.instance.ref().child('uploads/$_fileName');

    try {
      UploadTask uploadTask = storageReference.putData(_fileBytes!);
      TaskSnapshot taskSnapshot = await uploadTask.whenComplete(() => null);
      String fileURL = await taskSnapshot.ref.getDownloadURL();

      setState(() {
        _uploading = false;
        _uploadStatus = 'Upload successful! File URL: $fileURL';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload successful! File URL: $fileURL')),
      );
    } catch (e) {
      setState(() {
        _uploading = false;
        _uploadStatus = 'Upload failed: $e';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          ElevatedButton(
            onPressed: pickFile,
            child: Text('Select File'),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _uploading ? null : uploadFile,
            child:
                _uploading ? CircularProgressIndicator() : Text('Upload File'),
          ),
          SizedBox(height: 20),
          Text(_uploadStatus),
        ],
      ),
    );
  }
}
