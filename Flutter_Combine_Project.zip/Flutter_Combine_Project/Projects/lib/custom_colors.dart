import 'package:flutter/material.dart';

class CustomColors {
  static const Color cardColor = Color(0xFFd6eaff);
  static const Color dividerLine = Color(0xFFd1e0e0);
  static const Color textColorBlack = Color(0xFF1E1E1E);
}
