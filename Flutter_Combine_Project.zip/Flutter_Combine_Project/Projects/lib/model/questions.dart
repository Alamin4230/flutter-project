import 'package:my_protfolio1/model/question.dart';
//import 'package:my_protfolio1/models/question.dart';

const List<Question> questions = [
  Question(
    question: '1. what is 2+2',
    correctAnswerIndex: 1,
    options: [
      'a) 1',
      'b) 4',
      'c) 22',
      'd) 0',
    ],
  ),
  Question(
    question: '2. daffodil is a/an',
    correctAnswerIndex: 2,
    options: [
      'a) Independent country',
      'b) Business',
      'c) School & university',
      'd) none of these',
    ],
  ),
  Question(
    question: '3. How many rivers in bangladesh?',
    correctAnswerIndex: 3,
    options: [
      'a) 64 rivers',
      'b) 9 rivers',
      'c) 7 rivers',
      'd) 907 rivers',
    ],
  ),
  Question(
    question: '4. Which of the following is NOT an anti-virus software ?',
    correctAnswerIndex: 1,
    options: [
      'a) Avast ',
      'b) Linux ',
      'c) Norton ',
      'd) Kaspersky ',
    ],
  ),
  Question(
    question: '5. English is an____?',
    correctAnswerIndex: 2,
    options: [
      'a) country',
      'b) river',
      'c) person',
      'd) International Language',
    ],
  ),
  Question(
    question: '6. What is the smallest bird?',
    correctAnswerIndex: 3,
    options: [
      'a) Parrot',
      'b) Sparrow',
      'c) Doyel',
      'd) Hamim bird',
    ],
  ),
  Question(
    question: '7. What is the highest mountain in the world?',
    correctAnswerIndex: 3,
    options: [
      'a) Mont Blanc',
      'b) Aconcagua',
      'c) Kilimanjaro',
      'd) Everest',
    ],
  ),
  Question(
    question: '8. Who wrote the play Romeo and Juliet?',
    correctAnswerIndex: 0,
    options: [
      'a) William Shakespeare',
      'b) Oscar Wilde',
      'c) Jane Austen',
      'd) Charles Dickens',
    ],
  ),
  Question(
    question:
        '9. What is the name of the famous painting by Leonardo da Vinci that depicts a woman?',
    correctAnswerIndex: 3,
    options: [
      'a) Starry Night',
      'b) The Persistence of Memory',
      'c) The Last Supper',
      'd) Mona Lisa',
    ],
  ),
  Question(
    question:
        '10. Which unit of the computer is considered as the brain of the computer ?',
    correctAnswerIndex: 2,
    options: [
      'a) Memory unit ',
      'b) Input unit ',
      'c) CPU ',
      'd) Output unit ',
    ],
  ),
];
