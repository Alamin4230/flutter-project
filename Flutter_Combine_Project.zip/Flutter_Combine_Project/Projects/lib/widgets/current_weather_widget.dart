import 'package:flutter/material.dart';
import 'package:my_protfolio1/model/weather_data_current.dart';
import 'package:my_protfolio1/utils/custom_colors.dart';

class CurrentWeatherWidget extends StatelessWidget {
  final WeatherDataCurrent weatherDataCurrent;

  const CurrentWeatherWidget({Key? key, required this.weatherDataCurrent})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.8),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            offset: Offset(0, 4),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        children: [
          // Temperature area
          temperatureAreaWidget(),
          const SizedBox(height: 20),
          // More details - windspeed, humidity, clouds
          currentWeatherMoreDetailsWidget(),
        ],
      ),
    );
  }

  Widget temperatureAreaWidget() {
    final weather = weatherDataCurrent.current.weather?.first;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Image.network(
          'https://openweathermap.org/img/wn/${weather?.icon}@2x.png',
          height: 80,
          width: 80,
        ),
        Container(
          height: 50,
          width: 1,
          color: CustomColors.dividerLine,
        ),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: "${weatherDataCurrent.current.temp?.toInt()}°",
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 68,
                  color: CustomColors.textColorBlack,
                ),
              ),
              TextSpan(
                text: " ${weather?.description}",
                style: const TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget currentWeatherMoreDetailsWidget() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildDetailIcon("assets/icons/windspeed.png",
                "${weatherDataCurrent.current.windSpeed?.toStringAsFixed(1)} km/h"),
            _buildDetailIcon("assets/icons/clouds.png",
                "${weatherDataCurrent.current.clouds} %"),
            _buildDetailIcon("assets/icons/humidity.png",
                "${weatherDataCurrent.current.humidity} %"),
          ],
        ),
      ],
    );
  }

  Widget _buildDetailIcon(String assetPath, String value) {
    return Column(
      children: [
        Container(
          height: 60,
          width: 60,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: CustomColors.cardColor,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Image.asset(assetPath),
        ),
        const SizedBox(height: 10),
        Text(
          value,
          style: const TextStyle(fontSize: 12, color: Colors.black87),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
