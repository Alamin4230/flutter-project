import 'package:flutter/material.dart';
import 'package:my_protfolio1/widgets/current_weather_widget.dart';
import 'package:my_protfolio1/model/weather_data_current.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: WeatherScreen(),
  ));
}

class WeatherScreen extends StatelessWidget {
  // Simulated API response
  final weatherData = WeatherDataCurrent.fromJson({
    "current": {
      "temp": 25,
      "feels_like": 27.0,
      "humidity": 60,
      "clouds": 75,
      "uvi": 5.0,
      "wind_speed": 3.5,
      "weather": [
        {"id": 800, "main": "Clear", "description": "clear sky", "icon": "01d"}
      ]
    }
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1E1E1E),
      appBar: AppBar(
        title: Text('Weather'),
        backgroundColor: Color(0xFF2E3139),
      ),
      body: Center(
        child: CurrentWeatherWidget(weatherDataCurrent: weatherData),
      ),
    );
  }
}
